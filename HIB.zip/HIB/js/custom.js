(function () {
"use strict";
'use strict';
 
var app = angular.module('viewCustom', ['angularLoad']);
/****************************************************************************************************/
/*In case of CENTRAL_PACKAGE - comment out the below line to replace the other module definition*/
/*var app = angular.module('centralCustom', ['angularLoad']);*/
/****************************************************************************************************/
 
// Begin BrowZine - Primo Integration...
  window.browzine = {
    api: "https://public-api.thirdiron.com/public/v1/libraries/1463",
    apiKey: "dc2062cd-097a-4c27-8038-8edfe3066560",
    journalBrowZineWebLinkText: "Vis innhold i tidsskrift",
    articleBrowZineWebLinkText: "Vis innhold i tidsskrift-hefte",
    articlePDFDownloadLinkEnabled: true,
    articlePDFDownloadLinkText: "Last ned artikkel",
  };
 
  browzine.script = document.createElement("script");
  browzine.script.src = "https://s3.amazonaws.com/browzine-adapters/primo/browzine-primo-adapter.js";
  document.head.appendChild(browzine.script);
 
  app.controller('prmSearchResultAvailabilityLineAfterController', function($scope) {
    window.browzine.primo.searchResult($scope);
  });
 
  app.component('prmSearchResultAvailabilityLineAfter', {
    bindings: { parentCtrl: '<' },
    controller: 'prmSearchResultAvailabilityLineAfterController'
  });
// ... End BrowZine - Primo Integration
 
})();